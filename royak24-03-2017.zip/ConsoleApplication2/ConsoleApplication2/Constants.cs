﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VectorGraphicsEditor
{
    public static class Constants
    {
        // Эпсилон для сравнения точек
        public const double epsForEqualPoints = 10E-10;
    }
}
